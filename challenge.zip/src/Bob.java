public class Bob {

	public String speak(String input) {
		return "";
	}
}
